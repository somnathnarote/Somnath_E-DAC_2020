class HelloWorld{

public static void main(String[] args){

System.out.println("Hey Vikas Hello to Programming World");

}

}