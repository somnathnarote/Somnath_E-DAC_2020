class Swap
{
public static void main(String[] args)
{
float a=20f, b= 30f;
System.out.println("Before Swapping");
System.out.println("First number = " +a);
System.out.println("Second number = " +b);
a = a-b;
b = a+b;
a = b-a;
System.out.println("After Swapping");
System.out.println("First number = " +a);
System.out.println("Second number = " +b);
}
}
