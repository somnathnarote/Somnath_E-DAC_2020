import java.util.Scanner;
class Multbin
{
public static void main(String[] args)
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter first number:");
String a = sc.nextString();
System.out.println("Enter second number:");
String b = sc.nextString();
String BinaryString = Integer.toBinaryString(z);
String z = a * b;
System.out.println(""Product of binary no are:" +z); 
}
}