class Addition
{
	public static void main(String args[])
	{
	int num1=5,num2=15;
	int sum= num1 + num2;
	System.out.println("The sum is=" +sum);
	}
}