class Octtodec
{
public static void main(String[] args)
{
 String octnum = "10";
int num = Integer.parseInt(octnum, 8);
System.out.println("Decimal value is:" +num);
}
}
