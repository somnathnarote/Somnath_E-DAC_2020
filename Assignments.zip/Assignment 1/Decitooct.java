class Decitooct
{
public static void main(String[] args)
{
System.out.println(Integer.toOctalString(15));
System.out.println("octal value is:" +num);
}
}