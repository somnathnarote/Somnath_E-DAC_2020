import java.util.Scanner;
class Multiplicationtable
{
	public static void main(String[] args)
	{
	Scanner s1 = new Scanner(System.in);
	System.out.println("Enter number:");
	int n = s1.nextInt();
int i;
	for(i=1; i<=10; i++)
	{
	System.out.println(n+"*"+i+"="+n*+i);
	}
	}
}