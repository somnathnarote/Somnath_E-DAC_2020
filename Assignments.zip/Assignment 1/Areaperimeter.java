class Areaperimeter
{
	public static void main(String[] args)
	{
	double W = 5.5, L = 8.5,area,perimeter;
	area = W*L;
	perimeter = 2*(W+L);
	System.out.println("Area of rectangle:" +area);
	System.out.println("Perimeter of rectangle:" +perimeter);
	}
}