class CommandLine
{
public static void main(String... args)
{
String st = args[0];
System.out.println("Welcome +args[st]");
}
}