class Hello
{
	public static void main(String... W)
	{
		System.out.println("Hello World");
	}
}