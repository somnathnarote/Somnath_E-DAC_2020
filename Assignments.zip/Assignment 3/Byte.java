class Byte
{
public static void main(String... A)
{
double i = 12;
byte b1 = (byte)i;
System.out.println(b1);
}
}