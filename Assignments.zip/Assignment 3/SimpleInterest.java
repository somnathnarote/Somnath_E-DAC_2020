class SimpleInterest
{
public static void main(String []args)
{
float si, p=100000,r=18,t=2;
si=(p*r*t/100);
System.out.println("Simple Interest:" +si);
}
}