class Rollno
{
	public static void main(String ...V)
	{
		int rollno = 100;
		System.out.println("Roll no:" +rollno);
}
}